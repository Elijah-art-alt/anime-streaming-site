# Anime Streaming Prototype

This repository contains a full-stack anime streaming prototype:
- Backend: Node.js + Express + MongoDB
- Frontend: Static client files (HTML/CSS/JS)
- Authentication with JWT (HTTP-only cookie), password hashing with bcrypt
- Seed script to create sample anime and a demo user

## Quickstart (local)

1. Install Node.js and MongoDB.
2. From `server/`:
   - `npm install`
   - copy `.env.example` to `.env` and set values
   - `npm run seed`
   - `npm run dev`
3. Serve the `client/` folder (e.g., `npx serve client`) or open `client/index.html` in your browser.
4. Demo account: `demo@example.com` / `password123`

## Deploy

- Push this repo to GitHub and connect to Vercel/Render. Set environment variables (MONGO_URI, JWT_SECRET, CLIENT_URL).
