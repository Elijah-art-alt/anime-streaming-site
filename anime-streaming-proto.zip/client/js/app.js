const API = 'http://localhost:4000/api';

async function fetchJSON(path, opts = {}) {
  const r = await fetch(API + path, { credentials: 'include', headers: { 'Content-Type': 'application/json' }, ...opts });
  if(!r.ok) throw new Error('API error ' + r.status);
  return r.json();
}

async function loadHome() {
  try{
    const featured = await fetchJSON('/anime?featured=true&limit=10');
    const newReleases = await fetchJSON('/anime?limit=10');

    const fcont = document.getElementById('featured-list');
    featured.forEach(a => fcont.appendChild(cardFor(a)));
    const ncont = document.getElementById('new-list');
    newReleases.forEach(a => ncont.appendChild(cardFor(a)));
  }catch(err){
    console.error(err);
  }
}

function cardFor(a) {
  const card = document.createElement('div'); card.className='card';
  const img = document.createElement('img'); img.src = a.poster || 'https://via.placeholder.com/300x420?text=Poster';
  const title = document.createElement('div'); title.textContent = a.title;
  card.appendChild(img); card.appendChild(title);
  card.onclick = () => { window.location.href = `anime.html?id=${a._id}`; };
  return card;
}

// initialize homepage
if(document.body.contains(document.getElementById('featured'))) loadHome();

// anime detail page
async function loadAnimeDetail() {
  const params = new URLSearchParams(location.search);
  const id = params.get('id');
  if(!id) return document.getElementById('anime-detail').innerHTML = '<p>Missing id</p>';
  const a = await fetchJSON('/anime/' + id);
  const container = document.getElementById('anime-detail');
  container.innerHTML = `
    <div class="grid">
      <div style="max-width:320px"><img src="${a.poster||''}" style="width:100%;border-radius:8px"/></div>
      <div style="padding-left:20px">
        <h1>${a.title}</h1>
        <p>${a.synopsis||''}</p>
        <p>Rating: ${a.rating || 'N/A'}</p>
        <div id="episodes"></div>
      </div>
    </div>
  `;
  const epcont = container.querySelector('#episodes');
  a.episodes.forEach(ep => {
    const d = document.createElement('div');
    d.innerHTML = `<button data-ep="${ep.number}">Play Ep ${ep.number}</button> ${ep.title}`;
    d.querySelector('button').onclick = async () => {
      alert('Open player (placeholder). Marking as watched.');
      await fetch('/api/user/progress', { method: 'POST', credentials: 'include', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ animeId: a._id, episode: ep.number }) });
    };
    epcont.appendChild(d);
  });
}

if(document.body.contains(document.getElementById('anime-detail'))) loadAnimeDetail();

// dashboard
async function loadDashboard() {
  try{
    const d = await fetchJSON('/user/dashboard');
    const c = document.getElementById('dashboard');
    c.innerHTML = `<h2>Favorites</h2><div id="fav-row" class="card-row"></div><h2>Continue Watching</h2><div id="cont" class="card-row"></div>`;
    const favRow = c.querySelector('#fav-row');
    d.favorites.forEach(a=> favRow.appendChild(cardFor(a)));
    const cont = c.querySelector('#cont');
    d.progress.forEach(p => {
      const el = document.createElement('div'); el.className='card';
      el.innerHTML = `<img src="${p.anime.poster||''}" /><div>${p.anime.title}<div>Ep ${p.episode}</div></div>`;
      el.onclick = () => window.location.href = `anime.html?id=${p.anime._id}`;
      cont.appendChild(el);
    });
  }catch(err){
    console.error(err);
    document.getElementById('dashboard').innerHTML = '<p>Please login to view dashboard</p>';
  }
}

if(document.body.contains(document.getElementById('dashboard'))) loadDashboard();
