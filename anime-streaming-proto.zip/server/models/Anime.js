const mongoose = require('mongoose');

const EpisodeSchema = new mongoose.Schema({
  number: Number,
  title: String,
  duration: String,
  videoUrl: String
}, { _id: false });

const AnimeSchema = new mongoose.Schema({
  title: { type: String, required: true },
  synopsis: String,
  genres: [String],
  rating: Number,
  poster: String,
  featured: { type: Boolean, default: false },
  releaseDate: Date,
  episodes: [EpisodeSchema]
}, { timestamps: true });

module.exports = mongoose.model('Anime', AnimeSchema);
