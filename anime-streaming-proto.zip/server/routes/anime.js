const router = require('express').Router();
const Anime = require('../models/Anime');

// list with filters & search
router.get('/', async (req, res) => {
  const { q, genre, featured, limit = 20 } = req.query;
  const filter = {};
  if(featured === 'true') filter.featured = true;
  if(genre) filter.genres = genre;
  if(q) filter.title = new RegExp(q, 'i');
  const list = await Anime.find(filter).sort({ releaseDate: -1 }).limit(parseInt(limit));
  res.json(list);
});

router.get('/:id', async (req, res) => {
  const anime = await Anime.findById(req.params.id);
  if(!anime) return res.status(404).json({ message: 'Not found' });
  res.json(anime);
});

module.exports = router;
