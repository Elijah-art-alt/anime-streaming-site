const router = require('express').Router();
const User = require('../models/User');
const Anime = require('../models/Anime');
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'devsecret';
const COOKIE_NAME = 'token';

// simple auth middleware (reads cookie)
async function auth(req, res, next) {
  try {
    const token = req.cookies[COOKIE_NAME];
    if(!token) return res.status(401).json({ message: 'Not authenticated' });
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = await User.findById(payload.id);
    if(!req.user) return res.status(401).json({ message: 'Not authenticated' });
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Not authenticated' });
  }
}

router.get('/me', auth, async (req, res) => {
  const u = req.user.toObject();
  delete u.passwordHash;
  res.json(u);
});

// toggle favorite
router.post('/favorite/:animeId', auth, async (req, res) => {
  const animeId = req.params.animeId;
  const i = req.user.favorites.indexOf(animeId);
  if(i === -1) req.user.favorites.push(animeId);
  else req.user.favorites.splice(i, 1);
  await req.user.save();
  res.json({ favorites: req.user.favorites });
});

// mark progress
router.post('/progress', auth, async (req, res) => {
  const { animeId, episode } = req.body;
  if(!animeId || episode == null) return res.status(400).json({ message: 'Missing' });
  const prog = req.user.progress.find(p => p.anime.toString() === animeId);
  if(prog) { prog.episode = episode; prog.updatedAt = new Date(); }
  else req.user.progress.push({ anime: animeId, episode, updatedAt: new Date() });
  await req.user.save();
  res.json({ progress: req.user.progress });
});

router.get('/dashboard', auth, async (req, res) => {
  // populate favorites and progress
  await req.user.populate({ path: 'favorites', select: 'title poster rating' });
  const populatedProgress = await Promise.all(req.user.progress.map(async p => {
    const anime = await Anime.findById(p.anime).select('title poster rating episodes');
    return { anime, episode: p.episode, updatedAt: p.updatedAt };
  }));
  res.json({ favorites: req.user.favorites, progress: populatedProgress });
});

module.exports = router;
