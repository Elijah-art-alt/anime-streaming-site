require('dotenv').config();
const connectDB = require('./config/db');
const Anime = require('./models/Anime');
const User = require('./models/User');
const bcrypt = require('bcrypt');

async function seed() {
  await connectDB(process.env.MONGO_URI || 'mongodb://localhost:27017/anime_streaming');
  await Anime.deleteMany({});
  await User.deleteMany({});

  const sample = [
    {
      title: 'Skybound Guardians',
      synopsis: 'A group of pilots fight to protect the floating isles.',
      genres: ['Action','Adventure','Fantasy'],
      rating: 8.6,
      poster: '/assets/posters/skybound.jpg',
      featured: true,
      releaseDate: new Date('2024-10-01'),
      episodes: Array.from({length:12}).map((_,i)=>({ number: i+1, title: `Episode ${i+1}`, duration: '24m', videoUrl: '' }))
    },
    {
      title: 'Slice of Neon',
      synopsis: 'A cozy slice-of-life set in a neon metropolis.',
      genres: ['Slice of Life','Drama'],
      rating: 7.5,
      poster: '/assets/posters/neon.jpg',
      featured: false,
      releaseDate: new Date('2025-01-15'),
      episodes: Array.from({length:8}).map((_,i)=>({ number: i+1, title: `Part ${i+1}`, duration: '22m', videoUrl: '' }))
    }
  ];

  await Anime.insertMany(sample);

  const pw = await bcrypt.hash('password123', 10);
  await User.create({ username: 'demo', email: 'demo@example.com', passwordHash: pw });

  console.log('Seeded DB');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
